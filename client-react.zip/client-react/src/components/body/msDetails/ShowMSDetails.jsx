import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import axios from "axios"
import { useEffect, useState } from "react"
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';

import { Button } from "primereact/button";
import UpdateMSDetails from "./UpdateMSDetails";
import CreateMSDetails from "./CreateMSDetails";
import { useSelector } from "react-redux";
import { Toolbar } from "primereact/toolbar";
const ShowMSDetails = () => {
    const { token } = useSelector((state) => state.token);

    const [MSDetails, setMSDetails] = useState([])
    const [visible, setVisible] = useState(false)
    const [MSDetail, setMSDetail] = useState({})
    const getAllMSDetails = async () => {
        const res = await axios.get('http://localhost:1111/api/monthlyScholarshipDetails',
            { headers: { Authorization: `Bearer ${token}` } })
        setMSDetails(res.data)
    }
    useEffect(() => {
        getAllMSDetails()
    }, [])

    const deleteMSDetails = async (rowData) => {
        const res = await axios.delete(`http://localhost:1111/api/monthlyScholarshipDetails/${rowData._id}`,
            { headers: { Authorization: `Bearer ${token}` } })
        setMSDetails(res.data)
    }

    const updateButton = (rowData) => {
        return (
            <Button label="Update" icon="pi pi-pencil" onClick={() => {
                setMSDetail(rowData)
                setVisible(true)
            }} >Update</Button>)
    }
    const deleteButton = (rowData) => {
        return (
            <div className="flex align-items-center gap-2">
                <Button icon="pi pi-trash" onClick={() => deleteMSDetails(rowData)} className="p-button-rounded" /> </div>
        )
    }
const startContent = (
    <React.Fragment>
        <Button icon="pi pi-plus" className="mr-2" />
        <Button icon="pi pi-print" className="mr-2" />
        <Button icon="pi pi-upload" />
    </React.Fragment>
);
    return (<>
        <div className="card">
            <Toolbar start={<CreateMSDetails getAllMSDetails={getAllMSDetails} /> } start={startContext} /> 
            <Toolbar className="mb-4" />
        </div>
        {/* 
        <div className="card p-fluid">
            <DataTable value={users} editMode="row" dataKey="id" onRowEditComplete={onRowEditComplete} tableStyle={{ minWidth: '50rem' }}>
                <Column field="username" header="User name" editor={(options) => textEditor(options)} style={{ width: '20%' }}></Column>
                <Column field="name" header="Name" editor={(options) => textEditor(options)} style={{ width: '20%' }}></Column>
                {/* <Column field="inventoryStatus" header="Status" body={statusBodyTemplate} editor={(options) => statusEditor(options)} style={{ width: '20%' }}></Column>
                <Column field="price" header="Price" body={priceBodyTemplate} editor={(options) => priceEditor(options)} style={{ width: '20%' }}></Column> */}
        {/* <Column rowEditor={allowEdit} headerStyle={{ width: '10%', minWidth: '8rem' }} bodyStyle={{ textAlign: 'center' }}></Column> */}
        {/* //</></div> */}

        <div className="card">
            <DataTable value={MSDetails} tableStyle={{ minWidth: '50rem' }}>
                <Column field="sumPerHour" header="sumPerHour"></Column>
                <Column field="maximumNumberOfHours" header="MaximumNumberOfHours"></Column>
                <Column field="date" header="date"></Column>
                <Column header="DELETE" body={deleteButton}></Column>
                <Column header="UPDATE" body={updateButton}></Column>
            </DataTable>
            <UpdateMSDetails visible={visible} setVisible={setVisible} MSDetail={MSDetail} getAllMSDetails={getAllMSDetails} />

        </div>
    </>)
}
export default ShowMSDetails
