const CreateMSDetails=()=>{
    return(
        <></>
    )
}
export default CreateMSDetails;