import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import axios from "axios"
import { useEffect, useState } from "react"


import { Button } from "primereact/button";
import { Calendar } from "primereact/calendar";
import { InputText } from "primereact/inputtext";
import { useSelector } from "react-redux";
import { Dialog } from "primereact/dialog";

const UpdateMSDetails = (props) => {
    const MSDetails = props.MSDetails
    const setVisible = props.setVisible
    const visible = props.visible
    const [sumPerHour, setSumPerHour] = useState(MSDetails?.sumPerHour)
    const [maxNumOfHours, setMaxNumOfHours] = useState(MSDetails?.MaximumNumberOfHours)
    const { token } = useSelector((state) => state.token);
    const [date, setDate] = useState(MSDetails?.date)
    const updateMSDetails = async () => {
        await axios.put('http://localhost:1111/api/monthlyScholarshipDetails', { id: MSDetails._id, sumPerHour:sumPerHour,
             MaximumNumberOfHours:maxNumOfHours, date:date },
            { headers: { Authorization: `Bearer ${token}` } })
        props.getAllMSDetails()
    }
    return (<>
        <div className="card flex justify-content-center">
            <Dialog
                visible={visible}
                modal
                onHide={() => { if (!visible) return; setVisible(false); }}
                content={({ hide }) => (
                    <div className="flex flex-column px-8 py-5 gap-4" style={{ borderRadius: '12px', backgroundImage: 'radial-gradient(circle at left top, var(--primary-400), var(--primary-700))' }}>
                        <div className="inline-flex flex-column gap-2">
                            <label htmlFor="title" className="text-primary-50 font-semibold">Sum Per Hour</label>
                            <InputText type="number" value={sumPerHour} onChange={(e) => { setSumPerHour(e.value) }} className="bg-white-alpha-20 border-none p-3 text-primary-50" style={{ required: true }} />
                        </div>
                        <div className="inline-flex flex-column gap-2">
                            <label htmlFor="tags" className="text-primary-50 font-semibold">Maximun Number Of Hours</label>
                            <InputText type="number" className="bg-white-alpha-20 border-none p-3 text-primary-50" value={maxNumOfHours} onChange={(e) => setMaxNumOfHours(e.target.value)} style={{ required: true }} />
                        </div>
                        <div className="card flex justify-content-center">
                            <Calendar value={date} onChange={(e) => setDate(e.value)} />
                        </div>
                        <div className="flex align-items-center gap-2">
                            <Button label="Save" icon="pi pi-check" onClick={(e) => { updateMSDetails(); hide(e) }} text className="p-3 w-full text-primary-50 border-1 border-white-alpha-30 hover:bg-white-alpha-20"></Button>
                            <Button label="Cancel" icon="pi pi-times" onClick={(e) => hide(e)} text className="p-3 w-full text-primary-50 border-1 border-white-alpha-30 hover:bg-white-alpha-10"></Button>
                        </div>
                    </div>
                )}
            ></Dialog>
        </div>
    </>)
}
export default UpdateMSDetails;